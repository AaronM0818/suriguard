import React from 'react';
import { BarChart3, Users, Shield, AlertTriangle } from 'lucide-react';

const stats = [
  { icon: BarChart3, label: 'Total Traffic', value: '2.4M', change: '+12%' },
  { icon: AlertTriangle, label: 'Threats Blocked', value: '1,234', change: '-8%' },
  { icon: Shield, label: 'Active Rules', value: '156', change: '+3%' },
  { icon: Users, label: 'Active Users', value: '892', change: '+5%' },
];

export default function Dashboard() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-lg p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Icon className="text-blue-600" size={24} />
                </div>
                <span className={`text-sm ${
                  stat.change.startsWith('+') ? 'text-green-500' : 'text-red-500'
                }`}>
                  {stat.change}
                </span>
              </div>
              <h3 className="text-gray-500 text-sm">{stat.label}</h3>
              <p className="text-2xl font-semibold mt-1">{stat.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg p-6 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Traffic Overview</h2>
          <div className="h-64 flex items-center justify-center text-gray-400">
            Traffic Chart Placeholder
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-6 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Recent Events</h2>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((item) => (
              <div key={item} className="flex items-center justify-between py-2 border-b">
                <div>
                  <p className="font-medium">Security Alert #{item}</p>
                  <p className="text-sm text-gray-500">2 minutes ago</p>
                </div>
                <span className="px-3 py-1 text-sm bg-yellow-100 text-yellow-800 rounded-full">
                  Warning
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}