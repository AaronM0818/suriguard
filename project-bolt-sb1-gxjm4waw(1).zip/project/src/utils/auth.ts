// Mock authentication
const ADMIN_CREDENTIALS = {
  username: 'admin',
  password: 'admin'
};

export const authenticate = (username: string, password: string): boolean => {
  return username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password;
};

export const isAuthenticated = (): boolean => {
  return localStorage.getItem('isAuthenticated') === 'true';
};