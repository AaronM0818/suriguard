import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import PrivateRoute from './components/auth/PrivateRoute';
import AppLayout from './components/layout/AppLayout';
import Login from './pages/auth/Login';
import Dashboard from './pages/Dashboard';
import UserList from './pages/users/UserList';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        
        <Route path="/" element={
          <PrivateRoute>
            <AppLayout>
              <Dashboard />
            </AppLayout>
          </PrivateRoute>
        } />
        
        <Route path="/monitor" element={
          <PrivateRoute>
            <AppLayout>
              <div className="p-6">Real-time Monitor</div>
            </AppLayout>
          </PrivateRoute>
        } />
        
        <Route path="/logs" element={
          <PrivateRoute>
            <AppLayout>
              <div className="p-6">Log Management</div>
            </AppLayout>
          </PrivateRoute>
        } />
        
        <Route path="/events" element={
          <PrivateRoute>
            <AppLayout>
              <div className="p-6">Event Management</div>
            </AppLayout>
          </PrivateRoute>
        } />
        
        <Route path="/rules" element={
          <PrivateRoute>
            <AppLayout>
              <div className="p-6">Rules Management</div>
            </AppLayout>
          </PrivateRoute>
        } />
        
        <Route path="/users" element={
          <PrivateRoute>
            <AppLayout>
              <UserList />
            </AppLayout>
          </PrivateRoute>
        } />
        
        <Route path="/database" element={
          <PrivateRoute>
            <AppLayout>
              <div className="p-6">Database Management</div>
            </AppLayout>
          </PrivateRoute>
        } />
        
        <Route path="/settings" element={
          <PrivateRoute>
            <AppLayout>
              <div className="p-6">System Settings</div>
            </AppLayout>
          </PrivateRoute>
        } />
        
        <Route path="/more" element={
          <PrivateRoute>
            <AppLayout>
              <div className="p-6">More Features</div>
            </AppLayout>
          </PrivateRoute>
        } />
      </Routes>
    </Router>
  );
}

export default App;